
typedef struct cellule Cellule;